# NOTE: rightsform.pdf must be created manually

# Define the LaTeX compiler
# COMPILER = "pdflatex"
# COMPILER = "latex"
# COMPILER = "xelatex"
COMPILER="latexmk -pdf -interaction=nonstopmode"

# Define the zip command
ZIP="zip"

# First, ensure that all of the necessary PDFs are generated
$COMPILER instructions.tex
$COMPILER style-LaTeX.tex
$COMPILER style-other.tex
$COMPILER uploading-revisions.tex
$COMPILER template.tex

# Zip everything together using 
$ZIP instructions.zip \
  rightsform.pdf \
  instructions.pdf \
  LSAProceedingsAuthorInstructions.pdf \
  uploading-revisions.pdf \
  style-LaTeX.pdf \
  style-LaTeX.tex \
  template.tex \
  salt.cls \
  sp.bst \
  gb4e-salt.sty \
  submission-process.png \
  instructions.tex \
  style-other.pdf \
  template.pdf
